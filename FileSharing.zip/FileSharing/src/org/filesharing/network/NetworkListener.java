package org.filesharing.network;

import org.filesharing.user.NetUser;

public interface NetworkListener {
    public void onError(String message); // bir hata meydana geldiğinde
    public void onOnline(NetUser user); // bir cihaz online olduğu zaman
    public void onOffline();// bir cihaz offline olduğu zaman
}
