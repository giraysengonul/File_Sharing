/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.network;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.filesharing.user.NetUser;

/**
 *
 * @author katana
 */
class NetworkThread extends Thread {

    private boolean isRun;

    NetworkThread() {
        this.isRun = true;
    }

    public void setRun(boolean state) {
        this.isRun = state;
    }

    @Override
    public void run() {
        String siradakiIP;
        while (isRun) {
            synchronized (Network.ipList) {
                if (Network.ipList.size() <= 1) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(NetworkThread.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    continue;
                } else {
                    siradakiIP = Network.ipList.removeFirst();
                }
            }
            // IP yi al ve kontrol et
            try {
                if (InetAddress.getByName(siradakiIP).isReachable(1000)) {
                    try {
                        Socket s = new Socket(siradakiIP, 1623);
                        Network.getObject().addOnline(s);
                    } catch (IOException ex) {
                        synchronized (Network.ipList) {
                            Network.ipList.add(siradakiIP);
                        }
                    }
                } else {
                    synchronized (Network.ipList) {
                        Network.ipList.add(siradakiIP);
                    }
                }
                /*else {

                    for (NetUser u : Network.getObject().getOnlineList()) {
                        if (u.getUserName().equalsIgnoreCase(siradakiIP)) {
                            Network.getObject().removeOnline();
                        }
                    }

                }*/

            } catch (IOException ex) {
                // Başarısız olursa, bu IP adresini listeden çıkarıyoruz

            }
            // IP'yi geri iade et

        }
    }

}
