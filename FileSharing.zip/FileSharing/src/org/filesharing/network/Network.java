package org.filesharing.network;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.filesharing.socket.Server;
import org.filesharing.user.NetUser;

public class Network implements Runnable {

    private static Network network = null;
    private final LinkedList<NetUser> onlineList = new LinkedList<>();
    private final LinkedList<NetworkListener> listener = new LinkedList<>();
    private final int TIMEOUT = 10000, TNUMBER = 100;
    private boolean isRun = true;
    private InetAddress ip;
    ExecutorService executor = Executors.newFixedThreadPool(TNUMBER);
    static LinkedList<String> ipList = new LinkedList<>();

    private Network() {
        // Thread için executer service araştır
        // burada arkaplanda belirli aralıklarla Ağ taraması yapılacaktır
        this.ip = getWifiIp();
        if (this.ip == null) {
            System.out.println("WIFI ağı bulunamadı");
            System.exit(0);
        }
        new Thread(this).start();
    }

    public synchronized static Network getObject() {
        if (network == null) {
            network = new Network();
        }
        return network;
    }

    public void setRun(boolean state) {
        this.isRun = state;
    }

    public synchronized void addOnline(Socket s) {
        System.out.println("Test ediliyor: "+s.getInetAddress().getHostAddress());
        for(NetUser u:getObject().onlineList){
            if(u.getIP().equalsIgnoreCase(s.getInetAddress().getHostAddress())){
                try {
                    s.close();
                    return;
                } catch (IOException ex) {
                    Logger.getLogger(Network.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        NetUser n_user = new NetUser(s);
        getObject().onlineList.add(n_user);
        System.out.println("Online IP bulundu: " + s.getInetAddress().getHostAddress());

    }

    public synchronized void removeOnline() {
        // listener'lara haber ver
        // kullanıcı çıkarması yapılırken filtrelemeye bak
    }

    public LinkedList<NetUser> getOnlineList() {
        return getObject().onlineList;
    }

    public static InetAddress getWifiIp() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isUp() && !iface.isVirtual() && !iface.isLoopback() && iface.getName().contains("wlan")) {
                    if (iface.getInetAddresses().hasMoreElements()) {
                        return iface.getInetAddresses().nextElement();
                    } else {
                        return null;
                    }
                }
            }
        } catch (SocketException ex) {
        }
        return null;
    }

    private void fillList(LinkedList liste, String sub_net) {
        try {
            int pre = NetworkInterface.getByInetAddress(ip).getInterfaceAddresses().get(0).getNetworkPrefixLength();
            sub_net = ip.getHostAddress().substring(0, ip.getHostAddress().lastIndexOf("."));
            switch (pre) {
                case 24:
                    for (int i = 1; i < 255; i++) {
                        liste.add(String.format("%s.%s", sub_net, i));
                    }
                    break;
                default:
                    for (int i = 1; i < 255; i++) {
                        for (int k = 1; k < 255; k++) {
                            liste.add(String.format("%s.%s.%s", sub_net, i, k));
                        }
                    }
                    break;
            }
            //liste.remove(Network.getWifiIp().getAddress());
        } catch (SocketException ex) {
            Logger.getLogger(Network.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        String sub_net = ip.getHostAddress().substring(0, ip.getHostAddress().lastIndexOf("."));
        sub_net = sub_net.substring(0, sub_net.lastIndexOf("."));
        fillList(ipList, sub_net);

        for (int i = 0; i < TNUMBER; i++) {
            executor.execute(new NetworkThread());
        }

    }

    public void addListener(NetworkListener l) {
        listener.add(l);
    }

}
