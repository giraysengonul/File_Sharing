/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.utils;

import javax.swing.JOptionPane;

public class Message {

    public static void info(String... args) {
        switch (args.length) {
            case 1:
                message("Bilgi", args[0], JOptionPane.INFORMATION_MESSAGE);
                break;
            case 2:
                message(args[0], args[1], JOptionPane.INFORMATION_MESSAGE);
                break;
            default:
                // hata
                break;
        }
    }

    public static void error(String... args) {
        switch (args.length) {
            case 1:
                message("Hata", args[0], JOptionPane.ERROR_MESSAGE);
                break;
            case 2:
                message(args[0], args[1], JOptionPane.ERROR_MESSAGE);
                break;
            default:
                // hata
                break;
        }
    }

    static void message(String title, String msg, int type) {
        JOptionPane.showMessageDialog(null, msg, title, type);
    }
}
