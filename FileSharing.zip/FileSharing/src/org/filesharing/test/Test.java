/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.filesharing.network.Network;
import org.filesharing.network.NetworkListener;
import org.filesharing.socket.Client;
import org.filesharing.socket.ListenServer;
import org.filesharing.socket.SocketListener;
import org.filesharing.user.NetUser;

public class Test implements SocketListener{
    
    ListenServer l;
    Test(){
        try {
            l = new ListenServer();
            l.addListener(this);
        } catch (IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        Test t = new Test();
        
    }
    


    @Override
    public boolean onConfirm(Socket socket) {
        return true;
    }

    @Override
    public void onConnect(Socket socket,DataOutputStream writer,DataInputStream reader) {
        // bağlantı yaptıktan sonra dosyalar alınmalı
        try {
            System.out.println("Bağlantı isteği kabul edildi");
            System.out.println("Bağlanmak isteyen: "+socket.getInetAddress().getHostAddress());
            socket.close();
            System.out.println("Bağlantı kapandı");
        } catch (IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
