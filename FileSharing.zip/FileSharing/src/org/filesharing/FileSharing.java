package org.filesharing;

public class FileSharing {
    public static void main(String[] args){
        // kullanımdan kaldırıldı
    }

}
