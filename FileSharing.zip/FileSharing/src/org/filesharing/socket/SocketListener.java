/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 * Bu arayüzü uygulayan sınıflar, bir socket bağlantısı olduğunda
 * haberdar edilirler ve gerekli kaynakları parametre yardımıyla alarak işleyebilirler
 */
public interface SocketListener {
    boolean onConfirm(Socket socket); // bağlantı onayı alma veya onaylama
    void onConnect(Socket socket,DataOutputStream writer,DataInputStream reader);    // bağlantı onayından sonra bağlantı kaynaklarını arayüze iletme
}
