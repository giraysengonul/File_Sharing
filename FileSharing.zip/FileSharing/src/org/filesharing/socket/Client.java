package org.filesharing.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import org.filesharing.utils.FileListener;

/**
 * Dosya gönderme işleminde bu sınıf dosyayı gönderecek olan tarafta çalıştırılacaktır. Dosyayı göndereceği taraftan bilgileri alacak ve bağlantı kurarak dosyaları gönderecektir.
 */
public final class Client extends Thread {

    private final int PORT;
    private Socket client;
    private DataInputStream reader;
    private DataOutputStream writer;
    private final Scanner klavye = new Scanner(System.in);
    private final JFileChooser dosyaSec = new JFileChooser(".");
    private String IP = null;
    private FileListener listener = null;
    private boolean sendingState = true;

    public Client(String IP) {
        this.IP = IP;
        this.PORT = 1623;
    }

    public void addListener(FileListener l) {
        this.listener = l;
    }

    public void connect() {
        try {

            // bağlantı yapılacak
            client = new Socket(this.IP, this.PORT);
            reader = new DataInputStream(client.getInputStream());
            writer = new DataOutputStream(client.getOutputStream());
            this.start();
        } catch (IOException ex) {
            this.logError("" + ex);
        }
    }

    @Override
    public void run() {
        try {
            this.logMessage("bağlantı kuruldu");
            this.writer.writeUTF("connect");
            try {
                if (dosyaSec.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) {
                    this.logError("Dosya gönderimi iptal edildi");
                    writer.writeUTF("quit");
                } else {
                    String fileName = dosyaSec.getSelectedFile().getAbsolutePath();
                    sendFile(fileName);
                }
                writer.close();
                reader.close();
                client.close();
            } catch (IOException ex) {
                System.out.println("Hata: " + ex);
            }

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void sendFile(String fileName) {
        try {
            File dosya = new File(fileName);
            writer.writeUTF("send " + dosya.getName());
            this.logMessage("Cevap bekleniyor...");

            if (reader.readBoolean()) {
                this.logMessage("Kabul edildi. Dosya gönderiliyor");
                this.logStart();
                Socket file_client = new Socket(this.IP, 1624);
                if (dosya.exists()) {
                    BufferedInputStream r = new BufferedInputStream(new FileInputStream(dosya));
                    BufferedOutputStream f_out = new BufferedOutputStream(file_client.getOutputStream());
                    byte[] buffer = new byte[1024 * 1024 * 4]; // 1MB Buffer
                    long size = dosya.length();
                    float temp = 0;
                    int receive = 0, rate = 0;
                    writer.writeLong(size);

                    try {
                        while ((receive = r.read(buffer)) != -1 && sendingState) {
                            f_out.write(buffer, 0, receive);
                            temp += receive;
                            rate = (int) ((temp / (float) size) * 100);
                            this.logSend(rate);
                        }
                    } finally {
                        f_out.flush();
                        f_out.close();
                        file_client.close();
                        r.close();
                    }
                    this.writer.writeUTF("quit");
                    this.logFinish(false);

                }
            } else {
                this.writer.writeUTF("quit");
                this.logError("Karşı taraf dosyayı kabul etmedi");
            }

        } catch (FileNotFoundException ex) {
            this.logError("" + ex);
        } catch (IOException ex) {
            this.logError("" + ex);
        }
    }

    private void logStart() {
        if (this.listener != null) {
            this.listener.onStart();
        }
    }

    private void logSend(int rate) {
        if (this.listener != null) {
            this.listener.onSend(rate);
        }
    }

    private void logError(String error) {
        if (this.listener != null) {
            this.listener.onError(error);
        }
    }

    private void logMessage(String error) {
        if (this.listener != null) {
            this.listener.onMessage(error);
        }
    }

    private void logFinish(boolean withError) {
        if (this.listener != null) {
            this.listener.onFinish(withError);
        }
    }
}
