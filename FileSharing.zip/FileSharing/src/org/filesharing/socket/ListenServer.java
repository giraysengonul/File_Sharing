/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.socket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Kullanıcının online olduğunu bildiren ve sürekli bağlantı bekleyen bağlantı isteği olduğu zaman bunu ele alıp kullanıcı arayüzünden kullanıcının onayına sunarak gerekli kaynakları oluşturan ve yöneten sınıf
 *
 * Aynı zamanda bağlantı kurmadan, sadece bilgi isteyen kişilere de bilgileri sağlamak
 */
public class ListenServer extends Thread {

    private ServerSocket server;
    private LinkedList<SocketListener> listener = new LinkedList<>();
    private DataInputStream oku;
    private DataOutputStream yaz;
    private String kullanici_adi = "NABER";

    public ListenServer() throws IOException {
        this.server = new ServerSocket(1623,100);
        this.start();
    }

    public void addListener(SocketListener l) {
        this.listener.add(l);
    }

    public void notifyListener(Socket socket,DataOutputStream writer,DataInputStream reader) {
        for (SocketListener s : listener) {
            if (s.onConfirm(socket)) {
                System.out.println("Kabul etti");
                s.onConnect(socket,writer,reader);
            } else {
                System.out.println("Kabul etmedi");
            }
        }
    }

    @Override
    public void run() {
        try {
            while (true) {
                System.out.println("Dinleniyor...");
                Socket istemci = server.accept();
                new CommandParser(this,istemci).start();
            }
        } catch (IOException ex) {
            Logger.getLogger(ListenServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
