/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.filesharing.socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

class CommandParser extends Thread {

    private DataInputStream reader;
    private DataOutputStream writer;
    private Socket client;
    private String message = "", kullanici_adi = "sedat";
    private ListenServer root;

    CommandParser(ListenServer root, Socket client) {
        try {
            this.root = root;
            this.client = client;
            this.reader = new DataInputStream(this.client.getInputStream());
            this.writer = new DataOutputStream(this.client.getOutputStream());
        } catch (IOException ex) {
            System.out.println("CommandParser: " + ex.getMessage());
        }
    }

    @Override
    public void run() {
        if(this.client.isClosed()){
            System.out.println("Bağlantı sona ermiş");
            return;
        }
        while (!message.equalsIgnoreCase("quit")) {
            try {
                message = reader.readUTF();
                if (message.equalsIgnoreCase("look")) {
                    writer.writeUTF(kullanici_adi);
                    try {
                        this.reader.close();
                        this.writer.close();
                        this.client.close();
                    } catch (IOException ex) {
                        Logger.getLogger(CommandParser.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if (message.equalsIgnoreCase("connect")) {
                    this.root.notifyListener(client,writer,reader);
                }
            } catch (IOException ex) {
                message = "";
            }
        }

    }

}
