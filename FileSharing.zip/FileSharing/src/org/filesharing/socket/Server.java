package org.filesharing.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.filesharing.network.Network;
import org.filesharing.utils.FileListener;

/**
 * Dosya gönderme işleminde Server sınıfı, dosyaları alacak olan tarafta çalıştırılacaktır Böylece kendisine dosya göndermek isteyen taraf bu sınıf tarafından verilecek bilgileri kullanarak bağlanacak ve dosyaları gönderebilecektir.
 */
public class Server extends Thread {

    private ServerSocket server;
    private int PORT;
    private int LISTEN_NUMBER = 1;
    private Socket client;
    private DataInputStream reader;
    private DataOutputStream writer;
    private InetAddress wifiIp = null;
    private FileListener listener = null;

    public Server(int port) {
        wifiIp = Network.getWifiIp();
        if (wifiIp != null) {
            this.PORT = 1623;

        } else {
            this.logError("Wifi Ağı Bulunamadı");
            this.logFinish(true);
        }
    }

    public void listen() {
        new Thread(() -> {
            try {
                logStart();
                logMessage("ip " + wifiIp.getHostAddress());
                logMessage("Bağlantı bekleniyor...");
                server = new ServerSocket(PORT, LISTEN_NUMBER);
                client = server.accept();
                reader = new DataInputStream(client.getInputStream());
                writer = new DataOutputStream(client.getOutputStream());
                start();
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

    }

    @Override
    public void run() {
        this.logMessage("Bağlantı kuruldu");
        String message = "";
        // quit mesajı gelmediği sürece karşıdan mesajlar alınacak ve ekrana yazılacaktır
        while (!message.equalsIgnoreCase("quit")) {
            try {
                message = reader.readUTF();
            } catch (IOException ex) {
                continue;
            }
            if (message.contains("send ")) {
                String fileName = (message.split(" ").length) >= 2 ? message : null;
                if (fileName != null) {
                    getFile(fileName);
                } else {
                    this.logError("Dosya adı yok");
                    this.logFinish(true);
                }
            }
        }

        try {
            reader.close();
            writer.close();
            client.close();
            server.close();
        } catch (IOException ex) {
            this.logError("Hata: " + ex);
            this.logFinish(true);
            return;
        }
        this.logFinish(false);
    }

    public void getFile(String fileName) {
        try {
            File alinacakDosya = new File("receive_" + fileName.substring(5));

            if (!alinacakDosya.exists()) {
                alinacakDosya.createNewFile();
                ServerSocket file_server = new ServerSocket(1624, 1);
                int answer = JOptionPane.showConfirmDialog(null, "Dosya gönderilecek. Kabul ediyor musunuz?(" + alinacakDosya.getName() + ")");
                if (answer == JOptionPane.NO_OPTION || answer == JOptionPane.CANCEL_OPTION) {
                    writer.writeBoolean(false);
                    this.logError("Dosya kabul edilmedi");
                    this.logFinish(true);
                    file_server.close();
                    return;
                }
                writer.writeBoolean(true);
                Socket file_client = file_server.accept();

                BufferedInputStream f_input = new BufferedInputStream(file_client.getInputStream());
                BufferedOutputStream wr = new BufferedOutputStream(new FileOutputStream(alinacakDosya));

                byte[] buffer = new byte[1024 * 1024 * 4]; // 1MB Buffer
                int receive = 0;
                int rate = 0;
                float file_size = (float) reader.readLong();
                float temp = 0;

                while ((receive = f_input.read(buffer)) >= 0) {
                    wr.write(buffer, 0, receive);
                    temp += receive;
                    rate = (int) ((temp / file_size) * 100);
                    this.logSend(rate);
                }

                wr.flush();
                wr.close();
                file_client.close();
                file_server.close();

                this.logMessage("Dosya alındı: " + fileName);
            } else {
                JOptionPane.showMessageDialog(null, "Gönderilen dosya sizde mevcut", "Hata", JOptionPane.WARNING_MESSAGE);
                writer.writeBoolean(false);
                this.logFinish(true);
            }

        } catch (IOException ex) {
            this.logError("Hata: " + ex);
            this.logFinish(true);
        }

    }


    public void addListener(FileListener listener) {
        this.listener = listener;
    }

    private void logStart() {
        if (this.listener != null) {
            this.listener.onStart();
        }
    }

    private void logSend(int rate) {
        if (this.listener != null) {
            this.listener.onSend(rate);
        }
    }

    private void logError(String error) {
        if (this.listener != null) {
            this.listener.onError(error);
        }
    }

    private void logMessage(String error) {
        if (this.listener != null) {
            this.listener.onMessage(error);
        }
    }

    private void logFinish(boolean withError) {
        if (this.listener != null) {
            this.listener.onFinish(withError);
        }
    }
}
