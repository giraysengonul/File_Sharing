package org.filesharing.user;

// Online kullanıcı bilgilerinin tutulduğu sınıf
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.filesharing.socket.Server;

public class NetUser implements Runnable{

    private String userName="";
    private String IP;
    private int no=-1;
    private Socket user;
    
    public NetUser(Socket s) {
        this.IP = s.getInetAddress().getHostAddress();
        this.user = s;
        new Thread(this).start();
    }

    public String getUserName() {
        return userName;
    }

    public String getIP() {
        return this.IP;
    }

    public int getNo() {
        return no;
    }

    @Override
    public void run() {
        // burada karşıdan isim alıncak
        try {
            DataOutputStream y = new DataOutputStream(this.user.getOutputStream());
            DataInputStream o = new DataInputStream(this.user.getInputStream());
            String msg = "";
            y.writeUTF("look");
            y.flush();
            while (msg.equalsIgnoreCase("")) {
                try {
                    msg = o.readUTF();
                } catch (IOException ex) {
                    msg="";
                    continue;
                }
            }
            y.writeUTF("quit");
            y.close();
            o.close();
            this.user.close();
            this.userName = msg;
            System.out.println("[+] Kullanıcı adı başarıyla alındı");
        } catch (IOException ex) {
            System.out.println("[-] GetUserName: " + ex.getMessage());
        }
    }

}
