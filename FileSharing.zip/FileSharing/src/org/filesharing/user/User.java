package org.filesharing.user;

// program kullanıcısının bilgilerinin tutulduğu sınıf
public class User {
    
}
